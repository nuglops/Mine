# Keep the game simple and safe for release builds.
