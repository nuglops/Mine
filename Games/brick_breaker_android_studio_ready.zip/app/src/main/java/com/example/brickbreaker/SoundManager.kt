package com.example.brickbreaker

import android.content.Context
import android.media.SoundPool

class SoundManager(context: Context) {
    private val soundPool = SoundPool.Builder().setMaxStreams(8).build()
    private val sounds = HashMap<String, Int>()
    init {
        sounds["paddle"] = soundPool.load(context, R.raw.paddle, 1)
        sounds["brick"] = soundPool.load(context, R.raw.brick, 1)
        sounds["wall"] = soundPool.load(context, R.raw.wall, 1)
        sounds["powerup"] = soundPool.load(context, R.raw.powerup, 1)
        sounds["life"] = soundPool.load(context, R.raw.life, 1)
    }
    fun play(name: String) {
        sounds[name]?.let {
            val rate = 0.9f + kotlin.random.Random.nextFloat() * 0.2f
            soundPool.play(it, 1f, 1f, 1, 0, rate)
        }
    }
}
