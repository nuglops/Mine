package com.example.brickbreaker

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.random.Random

class BrickBreakerView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    private enum class Difficulty(
        val label: String,
        val rows: Int,
        val cols: Int,
        val paddleWidthFraction: Float,
        val ballSpeed: Float,
        val greyBarrierCount: Int,
        val brickDensity: Float,
        val speedUpgradeFactor: Float
    ) {
        EASY("Easy", 7, 8, 0.24f, 8.0f, 1, 0.90f, 1.04f),
        NORMAL("Normal", 8, 9, 0.22f, 9.0f, 2, 0.84f, 1.06f),
        HARD("Hard", 9, 10, 0.19f, 10.5f, 2, 0.78f, 1.08f),
        IMPOSSIBLE("Impossible", 10, 11, 0.16f, 12.0f, 3, 0.70f, 1.11f)
    }

    private enum class BrickType { COLOR, GREY }

    private data class Brick(
        val rect: RectF,
        val type: BrickType,
        val color: Int,
        var alive: Boolean = true
    )

    private data class Ball(
        var x: Float,
        var y: Float,
        var vx: Float,
        var vy: Float,
        val r: Float = 16f,
        var attached: Boolean = true
    )

    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textSize = 42f
    }
    private val smallPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.LTGRAY
        textSize = 28f
    }
    private val paddlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
    private val ballPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
    private val overlayPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(185, 0, 0, 0) }
    private val buttonPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(220, 36, 36, 36) }
    private val buttonStrokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        style = Paint.Style.STROKE
        strokeWidth = 3f
    }
    private val brickPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val flashPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val soundManager = SoundManager(context)

    private val rainbow = intArrayOf(
        Color.parseColor("#ff3333"), // red
        Color.parseColor("#ff7f11"), // orange
        Color.parseColor("#ffe533"), // yellow
        Color.parseColor("#28cc3f"), // green
        Color.parseColor("#2f7bff"), // blue
        Color.parseColor("#5b3fdc"), // indigo
        Color.parseColor("#a54cff")  // violet
    )

    private var difficulty: Difficulty? = null
    private var gameOver = false
    private var score = 0
    private var lives = 3
    private var level = 1
    private var widthPx = 0
    private var heightPx = 0

    private var paddleWidth = 0f
    private var paddleHeight = 24f
    private var paddleX = 0f
    private var paddleY = 0f
    private var paddleTouchOffset = 0f
    private var boardTop = 160f
    private var bottomInset = 44f

    private val balls = mutableListOf<Ball>()
    private val bricks = mutableListOf<Brick>()

    private var nextSplitScore = 20
    private var nextLifeScore = 50
    private var nextUpgradeScore = 25
    private var launchHintAlpha = 255

    private var shakeFrames = 0
    private var shakeMagnitude = 0f
    private var flashFrames = 0
    private var flashAlpha = 0
    private var flashColor = Color.WHITE

    private val chooserButtons = mutableListOf<Pair<Difficulty, RectF>>()
    private val restartRect = RectF()

    private val frameRunnable = object : Runnable {
        override fun run() {
            updateFrame()
            invalidate()
            postOnAnimation(this)
        }
    }

    init {
        isClickable = true
        post(frameRunnable)
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        widthPx = w
        heightPx = h
        paddleY = h - 120f
        bottomInset = max(48f, h * 0.05f)
        boardTop = max(150f, h * 0.10f)
        if (difficulty == null) {
            createDifficultyButtons()
        } else {
            updateLayoutForDifficulty()
        }
    }

    private fun createDifficultyButtons() {
        chooserButtons.clear()
        val buttonWidth = widthPx * 0.74f
        val buttonHeight = 96f
        val left = (widthPx - buttonWidth) / 2f
        val startY = heightPx * 0.36f
        val gap = 20f
        Difficulty.values().forEachIndexed { index, diff ->
            val top = startY + index * (buttonHeight + gap)
            chooserButtons += diff to RectF(left, top, left + buttonWidth, top + buttonHeight)
        }
    }

    private fun updateLayoutForDifficulty() {
        val diff = difficulty ?: return
        paddleWidth = widthPx * diff.paddleWidthFraction
        paddleX = widthPx / 2f
        balls.clear()
        bricks.clear()
        launchStartingBall()
        generateBoard()
    }

    private fun startGame(diff: Difficulty) {
        difficulty = diff
        gameOver = false
        score = 0
        lives = 3
        level = 1
        nextSplitScore = 20
        nextLifeScore = 50
        nextUpgradeScore = 25
        resetEffects()
        updateLayoutForDifficulty()
    }

    private fun restartGame() {
        difficulty?.let { startGame(it) }
    }

    private fun resetEffects() {
        shakeFrames = 0
        shakeMagnitude = 0f
        flashFrames = 0
        flashAlpha = 0
        flashColor = Color.WHITE
    }

    private fun launchStartingBall() {
        val ball = Ball(
            x = paddleX,
            y = paddleY - 34f,
            vx = 0f,
            vy = 0f,
            attached = true
        )
        balls += ball
        launchHintAlpha = 255
    }

    private fun generateBoard() {
        bricks.clear()
        val diff = difficulty ?: return
        val cols = diff.cols
        val rows = diff.rows + (level - 1) / 2
        val brickGap = 6f
        val usableWidth = widthPx - 32f
        val brickW = (usableWidth - brickGap * (cols - 1)) / cols
        val brickH = max(26f, min(44f, (heightPx * 0.045f)))
        val startX = 16f
        val startY = boardTop + 10f
        val random = Random(level * 1337 + diff.ordinal * 41)

        val barrierRows = mutableSetOf<Int>()
        val allowedRows = (1 until rows - 1).toMutableList()
        repeat(diff.greyBarrierCount.coerceAtMost(max(0, rows - 2))) {
            if (allowedRows.isEmpty()) return@repeat
            val idx = random.nextInt(allowedRows.size)
            barrierRows += allowedRows.removeAt(idx)
        }

        for (row in 0 until rows) {
            val y = startY + row * (brickH + brickGap)
            val rowType = if (barrierRows.contains(row)) BrickType.GREY else BrickType.COLOR
            for (col in 0 until cols) {
                if (rowType == BrickType.COLOR && random.nextFloat() > diff.brickDensity) continue
                val x = startX + col * (brickW + brickGap)
                val color = when (rowType) {
                    BrickType.GREY -> Color.GRAY
                    BrickType.COLOR -> rainbow[(row + col + level) % rainbow.size]
                }
                bricks += Brick(RectF(x, y, x + brickW, y + brickH), rowType, color)
            }
        }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (difficulty == null) {
            if (event.actionMasked == MotionEvent.ACTION_DOWN) {
                chooserButtons.firstOrNull { it.second.contains(event.x, event.y) }?.first?.let {
                    startGame(it)
                    return true
                }
            }
            return true
        }

        if (gameOver) {
            if (event.actionMasked == MotionEvent.ACTION_DOWN && restartRect.contains(event.x, event.y)) {
                restartGame()
            }
            return true
        }

        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                paddleTouchOffset = event.x - paddleX
                if (balls.any { it.attached }) {
                    launchAllAttachedBalls()
                }
                movePaddleTo(event.x - paddleTouchOffset)
            }
            MotionEvent.ACTION_MOVE -> movePaddleTo(event.x - paddleTouchOffset)
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                if (balls.any { it.attached }) {
                    launchAllAttachedBalls()
                }
            }
        }
        return true
    }

    private fun movePaddleTo(targetLeft: Float) {
        paddleX = targetLeft + paddleWidth / 2f
        paddleX = paddleX.coerceIn(paddleWidth / 2f, widthPx - paddleWidth / 2f)
        if (balls.any { it.attached }) {
            balls.filter { it.attached }.forEach {
                it.x = paddleX
                it.y = paddleY - it.r - 10f
            }
        }
    }

    private fun launchAllAttachedBalls() {
        val diff = difficulty ?: return
        val speed = diff.ballSpeed * (1f + (level - 1) * 0.05f)
        val launchAngles = listOf(-1.15f, -0.82f, -0.45f, -0.25f, 0.25f, 0.45f, 0.82f, 1.15f)
        var idx = 0
        balls.filter { it.attached }.forEach { ball ->
            val angle = launchAngles[idx % launchAngles.size]
            ball.vx = cos(angle) * speed
            ball.vy = -abs(sin(angle) * speed)
            ball.attached = false
            idx++
        }
    }

    private fun triggerImpact(shake: Float, flashColor: Int, flashAlpha: Int = 90, flashDuration: Int = 6) {
        shakeMagnitude = max(shakeMagnitude, shake)
        shakeFrames = max(shakeFrames, flashDuration)
        this.flashColor = flashColor
        this.flashAlpha = max(this.flashAlpha, flashAlpha)
        flashFrames = max(flashFrames, flashDuration)
    }

    private fun updateFrame() {
        if (difficulty == null || gameOver) return

        if (shakeFrames > 0) shakeFrames--
        if (flashFrames > 0) {
            flashFrames--
            if (flashFrames == 0) flashAlpha = 0
        }

        if (balls.isEmpty()) {
            lives--
            if (lives <= 0) {
                gameOver = true
                return
            }
            launchStartingBall()
            return
        }

        val diff = difficulty ?: return
        val speedBoost = diff.speedUpgradeFactor.pow((score / max(1, nextUpgradeScore)) + level / 3)
        val dt = 1f

        val paddleRect = RectF(paddleX - paddleWidth / 2f, paddleY, paddleX + paddleWidth / 2f, paddleY + paddleHeight)

        balls.forEach { ball ->
            if (ball.attached) {
                ball.x = paddleX
                ball.y = paddleY - ball.r - 10f
                return@forEach
            }

            ball.x += ball.vx * dt
            ball.y += ball.vy * dt

            // Walls
            if (ball.x - ball.r <= 0f) {
                ball.x = ball.r
                ball.vx = abs(ball.vx)
                triggerImpact(3f, Color.WHITE, 60, 4)
                soundManager.play("wall")
            } else if (ball.x + ball.r >= widthPx) {
                ball.x = widthPx - ball.r
                ball.vx = -abs(ball.vx)
                triggerImpact(3f, Color.WHITE, 60, 4)
                soundManager.play("wall")
            }
            if (ball.y - ball.r <= 0f) {
                ball.y = ball.r
                ball.vy = abs(ball.vy)
                triggerImpact(3f, Color.WHITE, 50, 3)
                soundManager.play("wall")
            }

            // Paddle collision
            if (circleRectHit(ball.x, ball.y, ball.r, paddleRect) && ball.vy > 0f) {
                val hitPos = ((ball.x - paddleRect.left) / paddleRect.width()).coerceIn(0f, 1f)
                val angle = (-150f + hitPos * 120f) * (PI / 180.0)
                val speed = max(7f, hypot(ball.vx, ball.vy)) * 1.01f
                ball.vx = (cos(angle) * speed).toFloat()
                ball.vy = -(abs(sin(angle) * speed)).toFloat()
                ball.y = paddleRect.top - ball.r - 1f
                triggerImpact(6f, Color.CYAN, 70, 5)
                soundManager.play("paddle")
            }

            // Brick collisions
            val hit = bricks.firstOrNull { it.alive && circleRectHit(ball.x, ball.y, ball.r, it.rect) }
            if (hit != null) {
                val oldX = ball.x - ball.vx
                val oldY = ball.y - ball.vy
                val reflectX = oldX < hit.rect.left || oldX > hit.rect.right
                val reflectY = oldY < hit.rect.top || oldY > hit.rect.bottom
                if (reflectX && !reflectY) ball.vx = -ball.vx
                else if (reflectY && !reflectX) ball.vy = -ball.vy
                else ball.vy = -ball.vy

                triggerImpact(if (hit.type == BrickType.GREY) 4f else 8f,
                    if (hit.type == BrickType.GREY) Color.LTGRAY else hit.color,
                    if (hit.type == BrickType.GREY) 55 else 110,
                    if (hit.type == BrickType.GREY) 4 else 7
                )

                if (hit.type == BrickType.COLOR) {
                    soundManager.play("brick")
                    hit.alive = false
                    score += 1
                    maybeAwardBonuses()
                    maybeUpgradeBallSpeed()
                } else {
                    soundManager.play("wall")
                }
                // Grey bricks are barriers: bounce only.
            }
        }

        balls.removeAll { it.y - it.r > heightPx + 20f }
        if (balls.isEmpty()) return

        if (bricks.none { it.alive && it.type == BrickType.COLOR }) {
            level++
            balls.forEach { if (!it.attached) it.vx *= 1.03f }
            launchStartingBall()
            generateBoard()
            triggerImpact(7f, Color.WHITE, 80, 6)
            soundManager.play("powerup")
        }

        if (balls.size == 1 && balls.firstOrNull()?.attached == true) launchHintAlpha = (launchHintAlpha - 6).coerceAtLeast(90)
        else launchHintAlpha = 255

        balls.forEach { ball ->
            if (!ball.attached) {
                val speed = hypot(ball.vx, ball.vy)
                val target = diff.ballSpeed * speedBoost
                if (speed < target) {
                    val scale = target / max(1f, speed)
                    ball.vx *= scale
                    ball.vy *= scale
                }
            }
        }
    }

    private fun maybeAwardBonuses() {
        while (score >= nextSplitScore) {
            splitAllBalls()
            nextSplitScore += 20
        }
        while (score >= nextLifeScore) {
            lives++
            nextLifeScore += 50
            triggerImpact(5f, Color.GREEN, 85, 5)
            soundManager.play("life")
        }
    }

    private fun maybeUpgradeBallSpeed() {
        if (score < nextUpgradeScore) return
        val diff = difficulty ?: return
        balls.forEach { ball ->
            if (!ball.attached) {
                ball.vx *= diff.speedUpgradeFactor
                ball.vy *= diff.speedUpgradeFactor
            }
        }
        paddleWidth = max(widthPx * 0.12f, paddleWidth * 0.985f)
        nextUpgradeScore += 25
        triggerImpact(4f, Color.YELLOW, 75, 5)
    }

    private fun splitAllBalls() {
        if (balls.size > 24) return
        val additions = mutableListOf<Ball>()
        balls.filter { !it.attached }.forEach { ball ->
            val vx = -ball.vx * 0.92f + (Random.Default.nextFloat() - 0.5f) * 2.2f
            val vy = ball.vy * 0.98f - 1.8f
            additions += Ball(ball.x, ball.y, vx, vy, ball.r, attached = false)
        }
        balls += additions
        if (balls.size > 1) launchHintAlpha = 255
        triggerImpact(5f, Color.MAGENTA, 90, 5)
        soundManager.play("powerup")
    }

    private fun circleRectHit(cx: Float, cy: Float, r: Float, rect: RectF): Boolean {
        val closestX = cx.coerceIn(rect.left, rect.right)
        val closestY = cy.coerceIn(rect.top, rect.bottom)
        val dx = cx - closestX
        val dy = cy - closestY
        return dx * dx + dy * dy <= r * r
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        canvas.drawColor(Color.rgb(12, 12, 18))

        val diff = difficulty
        if (diff == null) {
            drawTitleScreen(canvas)
            return
        }

        val dx = if (shakeFrames > 0) (Random.Default.nextFloat() - 0.5f) * shakeMagnitude else 0f
        val dy = if (shakeFrames > 0) (Random.Default.nextFloat() - 0.5f) * shakeMagnitude else 0f

        canvas.save()
        canvas.translate(dx, dy)
        drawHUD(canvas)
        drawBricks(canvas)
        drawPaddleAndBalls(canvas)
        if (gameOver) drawGameOver(canvas)
        else if (balls.any { it.attached }) drawLaunchHint(canvas)
        canvas.restore()

        if (flashAlpha > 0) {
            flashPaint.color = Color.argb(flashAlpha.coerceIn(0, 160), Color.red(flashColor), Color.green(flashColor), Color.blue(flashColor))
            canvas.drawRect(0f, 0f, widthPx.toFloat(), heightPx.toFloat(), flashPaint)
        }
    }

    private fun drawTitleScreen(canvas: Canvas) {
        val titlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            textSize = 60f
            textAlign = Paint.Align.CENTER
        }
        canvas.drawText("Brick Breaker", widthPx / 2f, heightPx * 0.18f, titlePaint)

        val subPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.LTGRAY
            textSize = 30f
            textAlign = Paint.Align.CENTER
        }
        canvas.drawText("Touch to move the paddle. Tap to launch.", widthPx / 2f, heightPx * 0.23f, subPaint)
        canvas.drawText("Pick a difficulty:", widthPx / 2f, heightPx * 0.30f, subPaint)

        val choiceTitlePaint = Paint(titlePaint).apply { textSize = 42f }
        val choiceDescPaint = Paint(subPaint).apply { textSize = 24f }
        chooserButtons.forEach { (diff, rect) ->
            canvas.drawRoundRect(rect, 18f, 18f, buttonPaint)
            canvas.drawRoundRect(rect, 18f, 18f, buttonStrokePaint)
            val centerY = rect.centerY() - (choiceTitlePaint.descent() + choiceTitlePaint.ascent()) / 2f
            canvas.drawText(diff.label, rect.centerX(), centerY, choiceTitlePaint)
            canvas.drawText(
                when (diff) {
                    Difficulty.EASY -> "More forgiveness"
                    Difficulty.NORMAL -> "Balanced"
                    Difficulty.HARD -> "Fast and tight"
                    Difficulty.IMPOSSIBLE -> "Brace yourself"
                },
                rect.centerX(),
                rect.bottom - 20f,
                choiceDescPaint
            )
        }
    }

    private fun drawHUD(canvas: Canvas) {
        val diff = difficulty ?: return
        val hudPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            textSize = 30f
        }
        canvas.drawText("Score: $score", 20f, 52f, hudPaint)
        canvas.drawText("Lives: $lives", 20f, 90f, hudPaint)
        canvas.drawText("Level: $level", widthPx / 2f - 60f, 52f, hudPaint)
        canvas.drawText(diff.label, widthPx - 200f, 52f, hudPaint)
        canvas.drawText("Next split: $nextSplitScore", widthPx - 260f, 90f, smallPaint)
        canvas.drawText("+life at $nextLifeScore", widthPx - 150f, 120f, smallPaint)
    }

    private fun drawBricks(canvas: Canvas) {
        bricks.filter { it.alive }.forEach { brick ->
            brickPaint.color = brick.color
            canvas.drawRoundRect(brick.rect, 10f, 10f, brickPaint)
            if (brick.type == BrickType.GREY) {
                val outline = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                    color = Color.argb(120, 255, 255, 255)
                    style = Paint.Style.STROKE
                    strokeWidth = 2f
                }
                canvas.drawRoundRect(brick.rect, 10f, 10f, outline)
            }
        }
    }

    private fun drawPaddleAndBalls(canvas: Canvas) {
        val paddleRect = RectF(paddleX - paddleWidth / 2f, paddleY, paddleX + paddleWidth / 2f, paddleY + paddleHeight)
        canvas.drawRoundRect(paddleRect, 18f, 18f, paddlePaint)

        if (shakeFrames > 0) {
            glowPaint.color = Color.argb(80, 255, 255, 255)
            canvas.drawRoundRect(paddleRect, 18f, 18f, glowPaint)
        }

        balls.forEach { ball ->
            ballPaint.color = if (ball.attached) Color.CYAN else Color.WHITE
            canvas.drawCircle(ball.x, ball.y, ball.r, ballPaint)
            if (shakeFrames > 0) {
                glowPaint.color = Color.argb(60, Color.red(ballPaint.color), Color.green(ballPaint.color), Color.blue(ballPaint.color))
                canvas.drawCircle(ball.x, ball.y, ball.r + 8f, glowPaint)
            }
        }
    }

    private fun drawLaunchHint(canvas: Canvas) {
        if (launchHintAlpha <= 0) return
        val hintPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.argb(launchHintAlpha, 255, 255, 255)
            textSize = 34f
            textAlign = Paint.Align.CENTER
        }
        canvas.drawText("Tap or drag to launch", widthPx / 2f, heightPx - 70f, hintPaint)
    }

    private fun drawGameOver(canvas: Canvas) {
        canvas.drawRect(0f, 0f, widthPx.toFloat(), heightPx.toFloat(), overlayPaint)
        val titlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            textSize = 64f
            textAlign = Paint.Align.CENTER
        }
        val bodyPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.LTGRAY
            textSize = 32f
            textAlign = Paint.Align.CENTER
        }
        canvas.drawText("Game Over", widthPx / 2f, heightPx * 0.40f, titlePaint)
        canvas.drawText("Final score: $score", widthPx / 2f, heightPx * 0.46f, bodyPaint)
        canvas.drawText("Level reached: $level", widthPx / 2f, heightPx * 0.51f, bodyPaint)

        restartRect.set(widthPx * 0.25f, heightPx * 0.58f, widthPx * 0.75f, heightPx * 0.68f)
        canvas.drawRoundRect(restartRect, 20f, 20f, buttonPaint)
        canvas.drawRoundRect(restartRect, 20f, 20f, buttonStrokePaint)
        val buttonTitlePaint = Paint(titlePaint).apply { textSize = 42f }
        canvas.drawText("Play again", restartRect.centerX(), restartRect.centerY() + 12f, buttonTitlePaint)
    }

    // Minimal pow helper without extra dependencies.
    private fun Float.pow(n: Int): Float {
        var result = 1f
        repeat(max(0, n)) { result *= this }
        return result
    }
}
