Open this folder in Android Studio (the folder with settings.gradle.kts), let Gradle sync, and run the app configuration.
