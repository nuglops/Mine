# Brick Breaker Touch

A native Android brick breaker game with:

- touchscreen paddle control
- 3 starting lives
- score-based extra lives every 50 points
- ball duplication every 20 points
- brick-speed upgrades as score rises
- random boards per level
- difficulty modes: Easy, Normal, Hard, Impossible
- grey barrier bricks that do not break

## What is included

This project is set up as a standard Android Studio app using Kotlin and a custom `View` renderer.

## Build for Google Play

Google Play currently requires new apps and app updates to target Android 15 (API level 35) or higher. Google Play also expects you to upload a signed Android App Bundle (`.aab`) using Play App Signing. citeturn356120search0turn356120search3turn356120search11

### Steps

1. Open the project in Android Studio.
2. Let Gradle sync.
3. Create a release keystore.
4. Use **Build > Generate Signed Bundle / APK**.
5. Choose **Android App Bundle**.
6. Upload the generated `.aab` to Play Console.

## Controls

- Drag anywhere to move the paddle.
- Tap to launch the ball.
- Tap a difficulty on the start screen.

## Notes

The gameplay is intentionally tuned to be simple and portable. You can tweak brick density, ball speed, and upgrade thresholds in `BrickBreakerView.kt`.
